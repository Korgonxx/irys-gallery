# Irys Gallery - On-Chain Art Gallery

## Project Overview

Irys Gallery is a decentralized web application that allows users to showcase and manage their digital art (images and videos) with permanent storage on the Irys blockchain. Users can connect their Solana wallets, create profiles, and manage their art collections.

## Features

### Core Features
- **Solana Wallet Integration**: Connect with Phantom, Solflare, and other Solana wallets
- **Permanent Storage**: All art and metadata stored permanently via Irys blockchain
- **Art Upload**: Support for images and videos
- **CRUD Operations**: Create, read, update, and delete uploaded art
- **User Profiles**: Custom username, avatar, bio, and social links (X, Discord)
- **Gallery Display**: Beautiful grid layout to showcase art collections

### User Experience
- Welcome message for first-time visitors
- Responsive design for desktop and mobile
- Intuitive wallet connection flow
- Profile setup wizard
- Easy art management interface

## Technical Architecture

### Frontend (React)
- **Framework**: React with Vite
- **Styling**: Tailwind CSS with shadcn/ui components
- **Wallet Integration**: Solana Web3.js and wallet adapters
- **State Management**: React hooks and context
- **Routing**: React Router DOM

### Backend (Flask)
- **Framework**: Flask with SQLite database
- **Blockchain Integration**: Irys SDK for permanent storage
- **API**: RESTful endpoints for all operations
- **CORS**: Enabled for frontend-backend communication
- **File Handling**: Multipart upload support

### Database Schema
```sql
-- Users table
users (
  id INTEGER PRIMARY KEY,
  wallet_address TEXT UNIQUE,
  username TEXT UNIQUE,
  avatar_url TEXT,
  bio TEXT,
  x_handle TEXT,
  discord_handle TEXT,
  created_at TIMESTAMP
)

-- Artworks table
artworks (
  id INTEGER PRIMARY KEY,
  user_id INTEGER,
  title TEXT,
  description TEXT,
  file_type TEXT,
  irys_id TEXT UNIQUE,
  file_url TEXT,
  thumbnail_url TEXT,
  created_at TIMESTAMP,
  updated_at TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users (id)
)
```

## Project Structure

```
irys-gallery/
├── frontend/          # React application
│   ├── src/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── lib/
│   │   └── assets/
│   └── package.json
├── backend/           # Flask API server
│   ├── src/
│   │   ├── models/
│   │   ├── routes/
│   │   └── main.py
│   └── requirements.txt
└── README.md
```

## Development Workflow

1. **Phase 1**: Project setup and architecture planning ✓
2. **Phase 2**: Frontend development with wallet integration
3. **Phase 3**: Backend API development with Irys integration
4. **Phase 4**: User profile management and social features
5. **Phase 5**: File upload, display, and CRUD operations
6. **Phase 6**: Testing, deployment, and final delivery

## Getting Started

### Frontend Development
```bash
cd frontend
pnpm run dev
```

### Backend Development
```bash
cd backend
source venv/bin/activate
python src/main.py
```

## Dependencies

### Frontend
- React + Vite
- Tailwind CSS
- shadcn/ui components
- @solana/web3.js
- @solana/wallet-adapter-react
- Lucide icons
- React Router DOM

### Backend
- Flask
- Flask-CORS
- SQLite
- Irys SDK
- Requests
- Pillow (for image processing)

## Deployment

The application will be deployed as a full-stack application with the React frontend served from Flask's static directory for seamless integration.

