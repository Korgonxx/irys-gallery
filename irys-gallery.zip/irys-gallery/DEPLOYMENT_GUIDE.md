# Irys Gallery - Deployment Guide

## Project Overview

Irys Gallery is a complete full-stack web application that allows users to connect their Solana wallets and upload digital art (images and videos) with permanent storage on the Irys blockchain. The application includes user profile management, social features, and a beautiful gallery interface.

## Architecture

### Frontend (React + Vite)
- **Framework**: React 19 with Vite build system
- **Styling**: Tailwind CSS with shadcn/ui components
- **Wallet Integration**: Solana Web3.js with wallet adapters
- **Features**: 
  - Welcome modal for first-time visitors
  - Wallet connection (Phantom, Solflare, etc.)
  - User profile setup and management
  - File upload interface with drag & drop
  - Gallery view with search and filtering
  - Responsive design for mobile and desktop

### Backend (Flask + SQLite)
- **Framework**: Flask with SQLAlchemy ORM
- **Database**: SQLite with user and artwork models
- **Blockchain Integration**: Irys service for permanent storage
- **Features**:
  - RESTful API endpoints
  - File upload handling (up to 50MB)
  - Image thumbnail generation
  - CORS enabled for frontend communication
  - User profile management
  - Artwork CRUD operations

### Database Schema

```sql
-- Users table
users (
  id INTEGER PRIMARY KEY,
  wallet_address TEXT UNIQUE,
  username TEXT UNIQUE,
  avatar_url TEXT,
  bio TEXT,
  x_handle TEXT,
  discord_handle TEXT,
  created_at TIMESTAMP
)

-- Artworks table
artworks (
  id INTEGER PRIMARY KEY,
  user_id INTEGER,
  title TEXT,
  description TEXT,
  file_type TEXT,
  irys_id TEXT UNIQUE,
  file_url TEXT,
  thumbnail_url TEXT,
  file_size INTEGER,
  mime_type TEXT,
  created_at TIMESTAMP,
  updated_at TIMESTAMP,
  views INTEGER DEFAULT 0,
  likes INTEGER DEFAULT 0
)
```

## API Endpoints

### User Management
- `POST /api/users/connect` - Connect wallet and create/get user
- `GET /api/users/wallet/{wallet_address}` - Get user by wallet address
- `PUT /api/users/{user_id}/profile` - Update user profile
- `GET /api/users/check-username/{username}` - Check username availability

### Artwork Management
- `GET /api/artworks` - Get artworks with pagination and filtering
- `POST /api/artworks` - Upload new artwork
- `GET /api/artworks/{artwork_id}` - Get specific artwork
- `PUT /api/artworks/{artwork_id}` - Update artwork metadata
- `DELETE /api/artworks/{artwork_id}` - Delete artwork
- `POST /api/artworks/{artwork_id}/like` - Like an artwork

### Health Check
- `GET /api/health` - API health status

## Local Development

### Prerequisites
- Node.js 20+ with pnpm
- Python 3.11+ with pip
- Git

### Setup Instructions

1. **Clone and setup the project**:
   ```bash
   git clone <repository-url>
   cd irys-gallery
   ```

2. **Backend Setup**:
   ```bash
   cd backend
   source venv/bin/activate
   pip install -r requirements.txt
   python src/main.py
   ```
   Backend will run on http://localhost:5000

3. **Frontend Setup**:
   ```bash
   cd frontend
   pnpm install
   pnpm run dev
   ```
   Frontend will run on http://localhost:5173

## Production Deployment

### Build Process

1. **Build Frontend**:
   ```bash
   cd frontend
   pnpm run build
   ```

2. **Copy to Flask Static Directory**:
   ```bash
   rm -rf ../backend/src/static/*
   cp -r dist/* ../backend/src/static/
   ```

3. **Deploy Backend**:
   ```bash
   cd backend
   source venv/bin/activate
   pip freeze > requirements.txt
   # Deploy using your preferred method (Docker, cloud platforms, etc.)
   ```

### Environment Variables

For production deployment, consider setting:
- `FLASK_ENV=production`
- `SECRET_KEY=<secure-random-key>`
- Database URL (if using external database)
- Irys configuration (API keys, network settings)

## Features Implemented

### ✅ Core Features
- [x] Solana wallet integration (Phantom, Solflare, etc.)
- [x] Welcome modal for first-time visitors
- [x] User profile setup with username, avatar, bio
- [x] Social media links (X/Twitter, Discord)
- [x] File upload (images and videos up to 50MB)
- [x] Irys blockchain integration for permanent storage
- [x] Gallery view with grid and list layouts
- [x] Search and filtering functionality
- [x] Like and view tracking
- [x] Responsive design
- [x] Profile management and editing
- [x] Artwork CRUD operations

### 🔧 Technical Features
- [x] RESTful API with proper error handling
- [x] Database models with relationships
- [x] File validation and processing
- [x] Thumbnail generation for images
- [x] CORS configuration
- [x] Pagination for large datasets
- [x] Real-time UI updates

## Known Limitations

1. **Irys Integration**: Currently uses a mock implementation for demonstration. In production, you would need:
   - Actual Irys SDK integration
   - Wallet funding for uploads
   - Proper transaction signing

2. **File Storage**: Files are currently stored temporarily during upload. In production:
   - Implement proper temporary file cleanup
   - Consider using cloud storage for staging

3. **Authentication**: Currently uses wallet address for authentication. Consider adding:
   - Session management
   - JWT tokens for API security

## Future Enhancements

1. **Advanced Features**:
   - NFT minting integration
   - Marketplace functionality
   - Social features (comments, follows)
   - Advanced search with tags
   - Bulk upload capabilities

2. **Performance Optimizations**:
   - Image optimization and CDN
   - Lazy loading for gallery
   - Caching strategies
   - Database indexing

3. **Security Enhancements**:
   - Rate limiting
   - Input sanitization
   - File type validation
   - CSRF protection

## Support

For questions or issues:
1. Check the API health endpoint: `/api/health`
2. Review browser console for frontend errors
3. Check Flask logs for backend issues
4. Ensure wallet extensions are installed and enabled

## License

This project is created for demonstration purposes. Please ensure compliance with relevant licenses when using in production.

